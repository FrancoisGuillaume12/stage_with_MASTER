-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le : jeu. 31 mars 2022 à 07:59
-- Version du serveur : 5.7.36
-- Version de PHP : 7.4.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `annuaire_de_maitre`
--

-- --------------------------------------------------------

--
-- Structure de la table `annuaire`
--

DROP TABLE IF EXISTS `annuaire`;
CREATE TABLE IF NOT EXISTS `annuaire` (
  `IDannuaire` int(11) NOT NULL AUTO_INCREMENT,
  `IDuser` int(11) NOT NULL,
  `nom` varchar(255) NOT NULL,
  `prenom` varchar(255) NOT NULL,
  `adresse` text NOT NULL,
  PRIMARY KEY (`IDannuaire`),
  KEY `user/annuaire` (`IDuser`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Structure de la table `annuaire/specialiter`
--

DROP TABLE IF EXISTS `annuaire/specialiter`;
CREATE TABLE IF NOT EXISTS `annuaire/specialiter` (
  `IDannuaire/specialiter` int(11) NOT NULL AUTO_INCREMENT,
  `IDspecialiter` int(11) NOT NULL,
  `IDannuaire` int(11) NOT NULL,
  PRIMARY KEY (`IDannuaire/specialiter`),
  KEY `annuaire/specialiter` (`IDannuaire`),
  KEY `annuaire/specialiter2` (`IDspecialiter`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Structure de la table `email`
--

DROP TABLE IF EXISTS `email`;
CREATE TABLE IF NOT EXISTS `email` (
  `IDemail` int(11) NOT NULL AUTO_INCREMENT,
  `IDannuaire` int(11) NOT NULL,
  `email` varchar(100) NOT NULL,
  PRIMARY KEY (`IDemail`),
  UNIQUE KEY `email` (`email`),
  KEY `annuaire/email` (`IDannuaire`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Structure de la table `numero_de_telephone`
--

DROP TABLE IF EXISTS `numero_de_telephone`;
CREATE TABLE IF NOT EXISTS `numero_de_telephone` (
  `IDnumero_de_telephone` int(11) NOT NULL AUTO_INCREMENT,
  `IDannuaire` int(11) NOT NULL,
  `numero_de_telephone` int(11) NOT NULL,
  PRIMARY KEY (`IDnumero_de_telephone`),
  KEY `annuaire/numero_telephone` (`IDannuaire`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Structure de la table `specialiter`
--

DROP TABLE IF EXISTS `specialiter`;
CREATE TABLE IF NOT EXISTS `specialiter` (
  `IDspecialiter` int(11) NOT NULL AUTO_INCREMENT,
  `specialiter` varchar(100) NOT NULL,
  PRIMARY KEY (`IDspecialiter`),
  UNIQUE KEY `specialiter` (`specialiter`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Structure de la table `user`
--

DROP TABLE IF EXISTS `user`;
CREATE TABLE IF NOT EXISTS `user` (
  `IDuser` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(100) NOT NULL,
  PRIMARY KEY (`IDuser`),
  UNIQUE KEY `nom` (`nom`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `annuaire`
--
ALTER TABLE `annuaire`
  ADD CONSTRAINT `user/annuaire` FOREIGN KEY (`IDuser`) REFERENCES `user` (`IDuser`);

--
-- Contraintes pour la table `annuaire/specialiter`
--
ALTER TABLE `annuaire/specialiter`
  ADD CONSTRAINT `annuaire/specialiter` FOREIGN KEY (`IDannuaire`) REFERENCES `annuaire` (`IDannuaire`),
  ADD CONSTRAINT `annuaire/specialiter2` FOREIGN KEY (`IDspecialiter`) REFERENCES `specialiter` (`IDspecialiter`);

--
-- Contraintes pour la table `email`
--
ALTER TABLE `email`
  ADD CONSTRAINT `annuaire/email` FOREIGN KEY (`IDannuaire`) REFERENCES `annuaire` (`IDannuaire`);

--
-- Contraintes pour la table `numero_de_telephone`
--
ALTER TABLE `numero_de_telephone`
  ADD CONSTRAINT `annuaire/numero_telephone` FOREIGN KEY (`IDannuaire`) REFERENCES `annuaire` (`IDannuaire`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
